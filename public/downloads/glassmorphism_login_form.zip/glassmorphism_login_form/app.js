function cardFlip() {
  const cardInner = document.querySelector("#flip-card-inner"),
    flipButtons = cardInner.querySelectorAll(".flip-button");

  flipButtons.forEach((button) => {
    button.addEventListener("click", () => {
      cardInner.classList.toggle("flipped");
      cardInner.classList.remove("animation-off")
    });
  });
}

function showPass() {
    const passwordContainers = document.querySelectorAll(".password-container");
    passwordContainers.forEach((container) => {
        const input = container.querySelector("input"),
        showHideButtons = container.querySelectorAll(".password-view");
        showHideButtons.forEach((button) => {
            button.addEventListener('click', () => {
                container.classList.toggle('shown');
                if (input.type === "password") {
                    input.type = "text";
                } else {
                    input.type = "password";
                }
            })
        })
    })
}

document.addEventListener("DOMContentLoaded", () => {
    cardFlip();
    showPass();
});
