function mobileNavOpen() {
  hamburgerIcon = document.querySelector("#hamburger-icon");

  hamburgerIcon.addEventListener("click", () => {
    // [NAV] = document.querySelector('#[NAV]');
    
    // [NAV.classlist.toggle('active');
    hamburgerIcon.classList.toggle("active");
    hamburgerIcon
      .querySelectorAll("div")
      .forEach((element) => element.classList.remove("animation-off"));
  });
}

document.addEventListener("DOMContentLoaded", () => {
  mobileNavOpen();
});
